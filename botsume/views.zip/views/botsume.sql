-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Nov 05, 2016 at 12:36 AM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `botsume`
--

-- --------------------------------------------------------

--
-- Table structure for table `bots`
--

CREATE TABLE `bots` (
  `id` int(11) NOT NULL,
  `userid` text NOT NULL,
  `botname` text NOT NULL,
  `description` text NOT NULL,
  `botid` text NOT NULL,
  `imgsrc` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bots`
--

INSERT INTO `bots` (`id`, `userid`, `botname`, `description`, `botid`, `imgsrc`) VALUES
(3, '8fe73918-8fdd-11e6-b750-c95758b58475', 'Nile Dixon Bot', 'This is a bot that mimics Nile Dixon.', '91430bac-9000-11e6-b750-c95758b58475', ''),
(4, '8fe73918-8fdd-11e6-b750-c95758b58475', 'Colby', '					Colby Bot', '11b4ef84-901b-11e6-b750-c95758b58475', ''),
(5, 'e9e0f156-9484-11e6-972b-601137ddb3e5', 'Mary Low Bot', '					Coffe ', 'f6ed1852-9484-11e6-972b-601137ddb3e5', ''),
(6, 'e9e0f156-9484-11e6-972b-601137ddb3e5', 'Harvard', '		This  is a bot about harvard			', 'c52d78b8-9b03-11e6-8280-f490f20c66da', ''),
(7, 'e9e0f156-9484-11e6-972b-601137ddb3e5', 'CP Bot', '				THis is a bot about CP	', '39abe2c6-9bb1-11e6-9333-3dc3182fa2a0', ''),
(8, '8fe73918-8fdd-11e6-b750-c95758b58475', 'Trump Bot', 'Mimics Trump					', 'ed44ffaa-a202-11e6-ae29-bb567f77d6cd', '');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(14) NOT NULL,
  `botid` text NOT NULL,
  `questionid` text NOT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `botid`, `questionid`, `question`, `answer`) VALUES
(1, '91430bac-9000-11e6-b750-c95758b58475', 'c624f28e-9007-11e6-b750-c95758b58475', 'Who are you?', 'I am a weird guy named Nile Dixon.'),
(2, '91430bac-9000-11e6-b750-c95758b58475', 'b1fa5024-900c-11e6-b750-c95758b58475', 'Where are you from?', 'I am from Houston, Texas.'),
(3, '91430bac-9000-11e6-b750-c95758b58475', 'bc203974-900c-11e6-b750-c95758b58475', 'Where do you go to college?', 'I go to Colby College.'),
(4, '91430bac-9000-11e6-b750-c95758b58475', 'ca188a2c-900c-11e6-b750-c95758b58475', 'How tall are you?', 'I am six feet and seven inches tall.'),
(5, '11b4ef84-901b-11e6-b750-c95758b58475', '1ae4ef78-901b-11e6-b750-c95758b58475', 'When was Colby created?', '1813'),
(6, '91430bac-9000-11e6-b750-c95758b58475', '97f6907e-9085-11e6-b750-c95758b58475', 'What are you majoring in?', 'Computer Science.'),
(7, 'f6ed1852-9484-11e6-972b-601137ddb3e5', '02430d1a-9485-11e6-972b-601137ddb3e5', 'What coffee do you serve?', 'We serve all types.'),
(8, 'c52d78b8-9b03-11e6-8280-f490f20c66da', 'dbff2ef6-9b03-11e6-8280-f490f20c66da', 'Are you a good school?', 'No t as good as Colby'),
(9, '39abe2c6-9bb1-11e6-9333-3dc3182fa2a0', '442569e8-9bb1-11e6-9333-3dc3182fa2a0', 'What school do you go to?', 'Colby'),
(10, 'ed44ffaa-a202-11e6-ae29-bb567f77d6cd', 'f7b230d4-a202-11e6-ae29-bb567f77d6cd', 'Do you like Hillary?', 'Hell no.');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `userid` text NOT NULL,
  `username` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `userid`, `username`, `email`, `password`) VALUES
(1, '8fe73918-8fdd-11e6-b750-c95758b58475', 'niledixon', 'niledixon475@gmail.com', 'ae78eb7905aa1eb6913f0126f0436cf803a16dd2'),
(2, 'e9e0f156-9484-11e6-972b-601137ddb3e5', 'csdixon', 'nedixo20@colby.edu', 'e44edcd101500715d19ff285b54e0c65b28fd626');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bots`
--
ALTER TABLE `bots`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bots`
--
ALTER TABLE `bots`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(14) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;