<div class = "container" style = "padding-top: 40px;">
	<h2 style = "text-align: center;">Everyone Can Make a Chatbot for their Business</h2>
	<div class = "row">
		<h3 style = "text-align: center;">What Can You Use a Chatbot For?</h3>
		<div class = "col-md-4">
			<div class = "well" style = "background-color: #2fe4a7;">
				<h4 style = "text-align: center; color: white;">Busniesses</h4>
				<p style = "text-align: center; color: white;">You can use chatbots to make it easier for people to learn more about your business.</p>
			</div>
		</div>
		<div class = "col-md-4">
			<div class = "well" style = "background-color: #2fe4a7;">
				<h4 style = "text-align: center; color: white;">Personal</h4>
				<p style = "text-align: center; color: white;">You can use chatbots to make it easier for people to learn more about yourself.</p>
			</div>
		</div>
		<div class = "col-md-4">
			<div class = "well" style = "background-color: #2fe4a7;">
				<h4 style = "text-align: center; color: white;">Personal</h4>
				<p style = "text-align: center; color: white;">You can use chatbots to make it easier for people to learn more about yourself.</p>
			</div>
		</div>
	</div>
</div>
<div class = "row" style = "background-color: #2fa4e7; padding-top: 10px; padding-bottom: 30px;">
	<div class ="container">
		<div class = "row">
			<form action = "search.php" method = "GET">
				<div class = "col-md-4">
					<label for = "search"><h2 style = "text-align: center; color: white;">Search for the chatbots</h2></label>
				</div>
				<div class = "col-md-6">
					<input id = "search" name = "s" type = "text" class = "form-control" style = "padding-top: 10px;">
				</div>
				<div class = "col-md-2">
					<button class = "btn" style = "background-color: #2fe4a7; color: white;">Search</button>
				</div>
			</form>
		</div>
	</div>
</div>